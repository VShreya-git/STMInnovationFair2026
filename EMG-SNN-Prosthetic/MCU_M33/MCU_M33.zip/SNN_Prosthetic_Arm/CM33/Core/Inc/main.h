/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.h
  * @brief          : Header for main.c file.
  ******************************************************************************
  */
/* USER CODE END Header */

#ifndef __MAIN_H
#define __MAIN_H

#ifdef __cplusplus
extern "C" {
#endif

/* ================= INCLUDES ================= */

#include "stm32mp2xx_hal.h"

#include "stm32mp2xx_ll_ucpd.h"
#include "stm32mp2xx_ll_bus.h"
#include "stm32mp2xx_ll_rcc.h"
#include "stm32mp2xx_ll_system.h"
#include "stm32mp2xx_ll_pwr.h"
#include "stm32mp2xx_ll_gpio.h"
#include "stm32mp2xx_ll_dma.h"
#include "stm32mp2xx_ll_exti.h"

#include <stdint.h>   // <-- Required for uint8_t etc
#include <string.h>

/* ================= FUNCTION PROTOTYPES ================= */

void Error_Handler(void);
void HAL_TIM_MspPostInit(TIM_HandleTypeDef *htim);

/* ================= GPIO DEFINES ================= */

/* LCD */
#define D6_Pin GPIO_PIN_5
#define D6_GPIO_Port GPIOZ

#define D7_Pin GPIO_PIN_8
#define D7_GPIO_Port GPIOZ

#define D5_Pin GPIO_PIN_7
#define D5_GPIO_Port GPIOZ

#define D4_Pin GPIO_PIN_6
#define D4_GPIO_Port GPIOZ

#define E_Pin GPIO_PIN_4
#define E_GPIO_Port GPIOZ

#define RS_Pin GPIO_PIN_3
#define RS_GPIO_Port GPIOZ

/* Charging Detect */
#define charging_Pin GPIO_PIN_9
#define charging_GPIO_Port GPIOZ

/* USB / Misc */
#define VCONN_CC2_EN_Pin GPIO_PIN_3
#define VCONN_CC2_EN_GPIO_Port GPIOC

#define VCONN_CC1_EN_Pin GPIO_PIN_5
#define VCONN_CC1_EN_GPIO_Port GPIOF

#define USB_SWOE_Pin GPIO_PIN_2
#define USB_SWOE_GPIO_Port GPIOH

#define USB_SWS_Pin GPIO_PIN_3
#define USB_SWS_GPIO_Port GPIOH

#define TCPP_INT_Pin GPIO_PIN_1
#define TCPP_INT_GPIO_Port GPIOG

#define TCCP_EN_Pin GPIO_PIN_3
#define TCCP_EN_GPIO_Port GPIOA

#define LED3_Pin GPIO_PIN_6
#define LED3_GPIO_Port GPIOH

#ifdef __cplusplus
}
#endif

#endif /* __MAIN_H */
