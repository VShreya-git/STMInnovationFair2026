#ifndef SNN_INFERENCE_H
#define SNN_INFERENCE_H

int snn_forward(float input[100][12]);

#endif
