#include "snn_inference.h"
#include "fc1_w.h"
#include "fc2_w.h"

/* ================= NETWORK DEFINES ================= */

#define INPUTS     12
#define HIDDEN     32
#define OUTPUTS    2
#define TIMESTEPS  100

static float beta = 0.95f;
static float threshold = 1.0f;

/* ================= NETWORK STATE ================= */

static float mem_hidden[HIDDEN];
static float mem_output[OUTPUTS];
static int   spike_count[OUTPUTS];

/* ================= LIF NEURON ================= */

static int lif(float *mem, float input)
{
    *mem = beta * (*mem) + input;

    if (*mem >= threshold)
    {
        *mem = 0.0f;
        return 1;
    }

    return 0;
}

/* ================= RESET NETWORK ================= */

static void reset_network(void)
{
    for(int i = 0; i < HIDDEN; i++)
        mem_hidden[i] = 0.0f;

    for(int i = 0; i < OUTPUTS; i++)
    {
        mem_output[i] = 0.0f;
        spike_count[i] = 0;
    }
}

/* ================= FORWARD PASS ================= */

int snn_forward(float input[TIMESTEPS][INPUTS])
{
    reset_network();

    for(int t = 0; t < TIMESTEPS; t++)
    {
        int hidden_spikes[HIDDEN];

        /* ----- Layer 1 ----- */
        for(int h = 0; h < HIDDEN; h++)
        {
            float sum = 0.0f;

            for(int i = 0; i < INPUTS; i++)
            {
                sum += input[t][i] *
                       fc1_weights[h * INPUTS + i];
            }

            hidden_spikes[h] = lif(&mem_hidden[h], sum);
        }

        /* ----- Layer 2 ----- */
        for(int o = 0; o < OUTPUTS; o++)
        {
            float sum = 0.0f;

            for(int h = 0; h < HIDDEN; h++)
            {
                sum += hidden_spikes[h] *
                       fc2_weights[o * HIDDEN + h];
            }

            if(lif(&mem_output[o], sum))
            {
                spike_count[o]++;
            }
        }
    }

    /* Decide gesture */
    if(spike_count[1] > spike_count[0])
        return 1;   // Grip
    else
        return 0;   // No Grip
}
