#include "main.h"
#include "openamp.h"
#include "rpmsg.h"
#include "snn_inference.h"
#include <string.h>

/* ================= CONFIG ================= */

#define TIMESTEPS   100
#define INPUTS      12

/* ================= PERIPHERALS ================= */

ADC_HandleTypeDef hadc1;
IPCC_HandleTypeDef hipcc1;

TIM_HandleTypeDef htim2;
TIM_HandleTypeDef htim4;
TIM_HandleTypeDef htim5;
TIM_HandleTypeDef htim6;
TIM_HandleTypeDef htim8;

/* ================= SNN BUFFER ================= */

float emg_buffer[TIMESTEPS][INPUTS];
uint16_t sample_index = 0;
uint8_t window_ready = 0;

/* ================= BATTERY ================= */

uint8_t battery = 89;
uint8_t charging_flag = 0;

/* ================= RPMSG ================= */

struct rpmsg_endpoint rp_ept;

typedef struct
{
    char type;      // 'B'
    uint8_t value;
} rpmsg_data_t;

/* ================= FUNCTION PROTOTYPES ================= */

void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_ADC1_Init(void);
static void MX_TIM2_Init(void);
static void MX_TIM4_Init(void);
static void MX_TIM5_Init(void);
static void MX_TIM6_Init(void);
static void MX_TIM8_Init(void);
static void MX_IPCC1_Init(void);

int MX_OPENAMP_Init(int RPMsgRole, rpmsg_ns_bind_cb ns_bind_cb);

void move_servos(uint8_t gesture);

/* ================= SIMPLE ADC READ ================= */

float read_emg_sample(void)
{
    HAL_ADC_Start(&hadc1);
    HAL_ADC_PollForConversion(&hadc1, HAL_MAX_DELAY);
    uint16_t value = HAL_ADC_GetValue(&hadc1);
    HAL_ADC_Stop(&hadc1);

    return (float)value / 4095.0f;
}

/* ================= SERVO CONTROL ================= */

void move_servos(uint8_t gesture)
{
    uint32_t open  = 50;
    uint32_t close = 70;

    if (gesture == 1)
    {
        __HAL_TIM_SET_COMPARE(&htim8, TIM_CHANNEL_4, close);
        __HAL_TIM_SET_COMPARE(&htim5, TIM_CHANNEL_1, close);
        __HAL_TIM_SET_COMPARE(&htim2, TIM_CHANNEL_4, close);
        __HAL_TIM_SET_COMPARE(&htim4, TIM_CHANNEL_2, close);
    }
    else
    {
        __HAL_TIM_SET_COMPARE(&htim8, TIM_CHANNEL_4, open);
        __HAL_TIM_SET_COMPARE(&htim5, TIM_CHANNEL_1, open);
        __HAL_TIM_SET_COMPARE(&htim2, TIM_CHANNEL_4, open);
        __HAL_TIM_SET_COMPARE(&htim4, TIM_CHANNEL_2, open);
    }
}

/* ================= BATTERY TIMER ================= */

void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
{
    if(htim->Instance == TIM6)
    {
        if(charging_flag)
        {
            if(battery < 100) battery += 5;
        }
        else
        {
            if(battery > 0) battery -= 5;
        }

        if(battery > 100) battery = 100;
        if(battery < 0) battery = 0;
    }
}

/* ================= MAIN ================= */

int main(void)
{
  HAL_Init();
  SystemClock_Config();

  /* ---- Init Peripherals ---- */

  MX_GPIO_Init();
  MX_ADC1_Init();
  MX_TIM2_Init();
  MX_TIM4_Init();
  MX_TIM5_Init();
  MX_TIM6_Init();
  MX_TIM8_Init();
  MX_IPCC1_Init();

  /* ---- OpenAMP ---- */

  MX_OPENAMP_Init(RPMSG_REMOTE, NULL);

  OPENAMP_create_endpoint(&rp_ept,
                          "rpmsg-openamp-demo-channel",
                          RPMSG_ADDR_ANY,
                          NULL,
                          NULL);

  /* ---- Start PWM ---- */

  HAL_TIM_PWM_Start(&htim8, TIM_CHANNEL_4);
  HAL_TIM_PWM_Start(&htim5, TIM_CHANNEL_1);
  HAL_TIM_PWM_Start(&htim2, TIM_CHANNEL_4);
  HAL_TIM_PWM_Start(&htim4, TIM_CHANNEL_2);

  /* ---- Start Battery Timer ---- */

  HAL_TIM_Base_Start_IT(&htim6);

  uint32_t last_batt_send = 0;

  /* ================= MAIN LOOP ================= */

  while (1)
  {
      charging_flag = HAL_GPIO_ReadPin(charging_GPIO_Port, charging_Pin);

      OPENAMP_check_for_message();
      OPENAMP_check_for_message();

      /* -------- Collect EMG Window -------- */

      if(!window_ready)
      {
          float sample = read_emg_sample();

          for(int ch = 0; ch < INPUTS; ch++)
          {
              emg_buffer[sample_index][ch] = sample;
          }

          sample_index++;

          if(sample_index >= TIMESTEPS)
          {
              window_ready = 1;
              sample_index = 0;
          }
      }

      /* -------- Run SNN -------- */

      if(window_ready)
      {
          int gesture = snn_forward(emg_buffer);

          move_servos(gesture);

          window_ready = 0;
      }

      /* -------- Send Battery to A35 -------- */

      if (HAL_GetTick() - last_batt_send > 1000)
      {
          last_batt_send = HAL_GetTick();

          rpmsg_data_t msg;
          msg.type = 'B';
          msg.value = battery;

          if (rp_ept.rpmsg_chnl)
          {
              rpmsg_send(&rp_ept, &msg, sizeof(msg));
          }
      }

      HAL_Delay(5);
  }
}

/* ================= ERROR HANDLER ================= */

void Error_Handler(void)
{
  __disable_irq();
  while (1)
  {
  }
}
